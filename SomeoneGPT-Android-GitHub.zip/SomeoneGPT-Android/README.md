# SomeoneGPT Android starter

This is an Android Kotlin + Jetpack Compose starter with a purple/black chat UI, a document picker for files/photos/videos, and a GitHub Actions workflow that builds a debug APK.

## Build APK
Open the repository's **Actions** tab and run **Build SomeoneGPT APK**. After the workflow succeeds, open its run and download the `SomeoneGPT-debug-apk` artifact.

## Current limitations
This is a UI starter, not a connected AI assistant. Messages are local demo messages. File selection is local only; files are not uploaded to a server. URL detection/preview, cloud AI, secure backend, and the user's custom background image still need implementation. Never put a private AI API key inside the APK.
