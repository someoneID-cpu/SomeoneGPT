package com.someonegpt.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SomeoneGPTApp() }
    }
}

private data class ChatLine(val text: String, val fromUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SomeoneGPTApp() {
    val context = LocalContext.current
    var draft by remember { mutableStateOf("") }
    var attachment by remember { mutableStateOf<String?>(null) }
    val messages = remember { mutableStateListOf(ChatLine("Halo! Aku SomeoneGPT. Antarmuka awal sudah siap. Koneksi AI akan ditambahkan setelah backend aman disiapkan.", false)) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            runCatching { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            attachment = it.lastPathSegment ?: "File terpilih"
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFB66CFF), secondary = Color(0xFF8A2BE2), background = Color(0xFF09060F), surface = Color(0xFF171020))) {
        Scaffold(containerColor = Color(0xFF09060F), topBar = {
            TopAppBar(title = {
                Column {
                    Text("SomeoneGPT", fontWeight = FontWeight.Bold, color = Color.White)
                    Text("HYBRID • PREVIEW", fontSize = 10.sp, color = Color(0xFFC69BFF), letterSpacing = 2.sp)
                }
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF130B20)))
        }, bottomBar = {
            Column(Modifier.fillMaxWidth().background(Color(0xFF130B20)).padding(10.dp)) {
                attachment?.let { Text("Lampiran: $it", color = Color(0xFFD9B9FF), modifier = Modifier.padding(start = 8.dp, bottom = 6.dp)) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { picker.launch(arrayOf("image/*", "video/*", "application/pdf", "text/*", "*/*")) }) {
                        Icon(Icons.Default.AttachFile, "Pilih file", tint = Color(0xFFD5B2FF))
                    }
                    OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("Tulis pesan atau tempel link...") }, shape = RoundedCornerShape(22.dp), maxLines = 4)
                    IconButton(onClick = {
                        val content = draft.trim()
                        if (content.isNotEmpty() || attachment != null) {
                            val full = buildString { if (content.isNotEmpty()) append(content); attachment?.let { if (isNotEmpty()) append("\n"); append("Lampiran: ").append(it) } }
                            messages.add(ChatLine(full, true)); draft = ""; attachment = null
                            messages.add(ChatLine("Pesan tersimpan di tampilan demo. Untuk jawaban AI sungguhan, backend/API belum dikonfigurasi.", false))
                        }
                    }) { Icon(Icons.Default.Send, "Kirim", tint = Color(0xFFCA9BFF)) }
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Brush.verticalGradient(listOf(Color(0xFF160A25), Color(0xFF09060F))))) {
                Surface(color = Color(0xFF241235), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("Unggah foto, video, atau file lewat ikon lampiran. Tautan bisa ditempel di kolom pesan. Ini masih prototipe UI—belum mengirim file ke server atau menjalankan AI.", color = Color(0xFFE9DDF5), fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(messages) { line ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                            Surface(color = if (line.fromUser) Color(0xFF54277C) else Color(0xFF21182B), shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                                Text(line.text, color = Color.White, modifier = Modifier.padding(13.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
